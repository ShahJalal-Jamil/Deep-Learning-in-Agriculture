# Agriculture_Paper_Implemetation

Comparison is   [HERE](https://docs.google.com/spreadsheets/d/1YuztcrLZnPBwqcxIX82mg521c48iL0LjPmsV7_RA-Cs/edit?usp=sharing).
